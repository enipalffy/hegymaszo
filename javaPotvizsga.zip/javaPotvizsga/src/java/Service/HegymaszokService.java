
package Service;

import java.util.List;
import javax.persistence.EntityManager;
import modells.Hegymaszok;
import org.json.JSONArray;



public class HegymaszokService {
    
     public boolean updateHegymaszoKepesseg(int id, EntityManager em) {

        try {
            Hegymaszok h = em.find(Hegymaszok.class, id);
            em.getTransaction().begin();
            h.setId(id);
            em.getTransaction().commit();
            return true;
        } catch (Exception ex) {
            return false;
        }
    }
    
     public JSONArray Hegymaszok(EntityManager em) {
        List<Hegymaszok> hegymaszok = Hegymaszok.getAllHegymaszo(em);
        JSONArray osszesHegymaszok = new JSONArray();
        for (Hegymaszok hm : hegymaszok) {
            osszesHegymaszok.put(hm.toJson());
        }
        return osszesHegymaszok;
    }
    }
    

