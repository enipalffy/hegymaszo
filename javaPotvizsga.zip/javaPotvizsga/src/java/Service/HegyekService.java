
package Service;


import java.util.List;
import javax.persistence.EntityManager;
import modells.Hegyek;
import org.json.JSONArray;

public class HegyekService {
    

    public JSONArray Hegyek(EntityManager em) {
        List< Hegyek> hegyek = Hegyek.getAllHegy(em);
        JSONArray osszesHegyek = new JSONArray();
        for (Hegyek h : hegyek) {
            osszesHegyek.put(h.toJson());
        }
        return osszesHegyek;
    }

    public boolean addNewHegy(int szelessegi_koordinata, int hosszusagi_koordinata, int magassag, int megmaszas_nehezseg, EntityManager em) {

        if (Hegyek.addNewHegy(szelessegi_koordinata, hosszusagi_koordinata, magassag, megmaszas_nehezseg, em)) {
            return true;
        } else {
            return false;
        }
    }

 
    
}
