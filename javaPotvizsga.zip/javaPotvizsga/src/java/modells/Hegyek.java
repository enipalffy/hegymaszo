
package modells;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import org.json.JSONObject;


@Entity
@Table(name = "hegyek")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Hegyek.findAll", query = "SELECT h FROM Hegyek h")
    , @NamedQuery(name = "Hegyek.findById", query = "SELECT h FROM Hegyek h WHERE h.id = :id")
    , @NamedQuery(name = "Hegyek.findBySzelessegiKoordinata", query = "SELECT h FROM Hegyek h WHERE h.szelessegiKoordinata = :szelessegiKoordinata")
    , @NamedQuery(name = "Hegyek.findByHosszusagiKoordinata", query = "SELECT h FROM Hegyek h WHERE h.hosszusagiKoordinata = :hosszusagiKoordinata")
    , @NamedQuery(name = "Hegyek.findByMagassag", query = "SELECT h FROM Hegyek h WHERE h.magassag = :magassag")
    , @NamedQuery(name = "Hegyek.findByMegmaszasNehezseg", query = "SELECT h FROM Hegyek h WHERE h.megmaszasNehezseg = :megmaszasNehezseg")})
public class Hegyek implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "szelessegi_koordinata")
    private int szelessegiKoordinata;
    @Basic(optional = false)
    @Column(name = "hosszusagi_koordinata")
    private int hosszusagiKoordinata;
    @Basic(optional = false)
    @Column(name = "magassag")
    private int magassag;
    @Basic(optional = false)
    @Column(name = "megmaszas_nehezseg")
    private int megmaszasNehezseg;

    public Hegyek() {
    }

    public Hegyek(Integer id) {
        this.id = id;
    }

    public Hegyek(Integer id, int szelessegiKoordinata, int hosszusagiKoordinata, int magassag, int megmaszasNehezseg) {
        this.id = id;
        this.szelessegiKoordinata = szelessegiKoordinata;
        this.hosszusagiKoordinata = hosszusagiKoordinata;
        this.magassag = magassag;
        this.megmaszasNehezseg = megmaszasNehezseg;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getSzelessegiKoordinata() {
        return szelessegiKoordinata;
    }

    public void setSzelessegiKoordinata(int szelessegiKoordinata) {
        this.szelessegiKoordinata = szelessegiKoordinata;
    }

    public int getHosszusagiKoordinata() {
        return hosszusagiKoordinata;
    }

    public void setHosszusagiKoordinata(int hosszusagiKoordinata) {
        this.hosszusagiKoordinata = hosszusagiKoordinata;
    }

    public int getMagassag() {
        return magassag;
    }

    public void setMagassag(int magassag) {
        this.magassag = magassag;
    }

    public int getMegmaszasNehezseg() {
        return megmaszasNehezseg;
    }

    public void setMegmaszasNehezseg(int megmaszasNehezseg) {
        this.megmaszasNehezseg = megmaszasNehezseg;
    }
    
     public JSONObject toJson() {
        JSONObject j = new JSONObject();
        j.put("id", this.id);
        j.put("hosszusagiKoordinata", this.hosszusagiKoordinata);
        j.put("szelessegiKoordinata", this.szelessegiKoordinata);
        j.put("magassag", this.magassag);
        j.put("megmaszasNehezseg", this.megmaszasNehezseg);
        return j;
    }
    
    
      public static boolean addNewHegy(int szelessegi_koordinata, int hosszusagi_koordinata, int magassag, int megmaszas_nehezseg, EntityManager em) {
        try {
            StoredProcedureQuery spq = em.createStoredProcedureQuery("addNewHegy");

            spq.registerStoredProcedureParameter("szelessegi_koordinataIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("hosszusagi_koordinataIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("magassagIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("megmaszas_nehezsegIN", Integer.class, ParameterMode.IN);

            spq.setParameter("szelessegi_koordinataIN", szelessegi_koordinata);
            spq.setParameter("hosszusagi_koordinataIN", hosszusagi_koordinata);
            spq.setParameter("magassagIN", magassag);
            spq.setParameter("megmaszas_nehezsegIN", megmaszas_nehezseg);

            spq.execute();
            return true;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }
      public static List<Hegyek> getAllHegy(EntityManager em){
        List<Hegyek> hegyek = new ArrayList();
        StoredProcedureQuery spq = em.createStoredProcedureQuery("getAllHegyMagassagCsokken");
        List<Object[]> lista = spq.getResultList();
        for(Object[] elem : lista){
            int id = Integer.parseInt(elem[0].toString());
            Hegyek h = em.find(Hegyek.class, id);
            hegyek.add(h);
        }
        return hegyek;
    }
    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Hegyek)) {
            return false;
        }
        Hegyek other = (Hegyek) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "potvizsga.Hegyek[ id=" + id + " ]";
    }
    
}
