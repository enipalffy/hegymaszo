
package Controller;

import Service.HegyekService;
import java.io.IOException;
import java.io.PrintWriter;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;


public class HegyekController extends HttpServlet {

  
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        try (PrintWriter out = response.getWriter()) {
            
            HegyekService hs = new HegyekService();

            EntityManagerFactory emf = Persistence.createEntityManagerFactory("javaPotvizsgaPU");
            EntityManager em = emf.createEntityManager();
            
               if (request.getParameter("task").equals("addNewHegy")) {

                int szelessegi_koordinata = Integer.parseInt(request.getParameter("szelessegi_koordinata"));
                int hosszusagi_koordinata = Integer.parseInt(request.getParameter("hosszusagi_koordinata"));
                int magassag = Integer.parseInt(request.getParameter("magassag"));
                int megmaszas_nehezseg = Integer.parseInt(request.getParameter("megmaszas_nehezseg"));
                JSONObject valasz = new JSONObject();

                if (hs.addNewHegy(szelessegi_koordinata, hosszusagi_koordinata, magassag, megmaszas_nehezseg, em)) {

                    valasz.put("msg", "A hegy hozzáadása megtörtént");
                } else {
                    valasz.put("msg", "A hegy hozzáadása nem történt meg");
                }
                out.write(valasz.toString());

            }
               
               if (request.getParameter("task").equals("getAllHegyMagassagCsokken")) {
                JSONArray a = hs.Hegyek(em);
                out.print(a.toString());
            }
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
